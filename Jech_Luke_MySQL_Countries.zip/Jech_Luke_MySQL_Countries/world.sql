SELECT region, count(id) as countries
FROM countries
GROUP BY(region)
ORDER BY countries DESC